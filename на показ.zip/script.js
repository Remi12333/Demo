
const burger = document.getElementById('burger');
const menu = document.getElementById('menu');
burger.addEventListener('click', () => menu.classList.toggle('active'));


const houseInput = document.getElementById('houseName');
function openForm(name) {
  document.getElementById('contacts').scrollIntoView({ behavior: 'smooth' });
  houseInput.value = name;
}


const contactsToggle = document.getElementById('contactsToggle');
const contactsPanel = document.getElementById('contactsPanel');
contactsToggle.addEventListener('click', () => contactsPanel.classList.toggle('active'));


const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('visible'); });
}, { threshold: 0.15 });
document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));
